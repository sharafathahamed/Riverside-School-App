# Copyright (c) 2026, Sharaf and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSyllabusProgress(FrappeTestCase):
	pass
